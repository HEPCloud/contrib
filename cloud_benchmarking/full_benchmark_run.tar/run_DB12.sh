#!/bin/bash

#####################################################################
# This example script installs and runs the HEP-Benchmark-Suite
#
# The Suite configuration file
#       bmkrun_config.yml
# is included in the script itself.
# The configuration script enables the benchmarks to run
# and defines some meta-parameters, including tags as the SITE name.
#
# In this example only the HS06 at 32 bits benchmark is configured to run.
# ****** IMPORTANT ********
# In order to run, the HS06 package needs to be available in the
# location assigned to the hepspec_volume parameter.
# As an alternative a tarball needs to be passed to the suite by 
# the parameter url_tarball
#
# Requirements 
#    - Install: python3-pip singularity
#    - Define values for the parameters SITE and PURPOSE 
#    - Make available the x509 key/cert files for the publication 
#
#
# Example:
# > yum install -y python3-pip singularity
# > curl -O https://gitlab.cern.ch/hep-benchmarks/hep-benchmark-suite/-/raw/master/examples/spec/run_HS06_32bits.sh
# > chmod u+x run_HS06_32bits.sh
# - MANDATORY: EDIT the user editable section
# > ./run_HS06_32bits.sh
#####################################################################

#--------------[Start of user editable section]---------------------- 
SITE=somesite  # Replace somesite with a meaningful site name
PUBLISH=false  # Replace false with true in order to publish results in AMQ
CERTIFKEY=path_to_user_key_pem  
CERTIFCRT=path_to_user_cert_pem
#--------------[End of user editable section]------------------------- 


echo "Running script: $0"
cd $( dirname $0)

WORKDIR=`pwd`/workdir
LOGFILE=$WORKDIR/output.txt
SERVER=dashb-mb.cern.ch
PORT=61123
TOPIC=/topic/vm.spec

echo "Creating the WORKDIR $WORKDIR"
mkdir -p $WORKDIR
chmod a+rw -R $WORKDIR

cat > $WORKDIR/bmkrun_config.yml <<EOF2
activemq:
  server: $SERVER
  topic: $TOPIC
  port: $PORT
  ## include the certificate full path (see documentation)
  key: $CERTIFKEY
  cert: $CERTIFCRT

global:
  benchmarks:
  - db12
  mode: singularity
  publish: $PUBLISH
  rundir: ${WORKDIR}/suite_results
  show: true
  tags:
    site: $SITE
    purpose: "TF measurements"

EOF2

cd $WORKDIR
export MYENV="env_bmk"        # Define the name of the environment.
python3 -m venv $MYENV        # Create a directory with the virtual environment.
source $MYENV/bin/activate    # Activate the environment.
python3 -m pip install setuptools-rust
python3 -m pip install --upgrade pip
python3 -m pip install git+https://gitlab.cern.ch/hep-benchmarks/hep-benchmark-suite.git
cat bmkrun_config.yml

if [ `cat bmkrun_config.yml | grep "this_is_dummy_replace_me" | grep -c -v "#"` == 1 ];
then
  echo -e "\nERROR. You are using the url_tarball parameter. Please replace the dummy url with a real one"
  exit 1
fi

bmkrun -c bmkrun_config.yml | tee -i $LOGFILE

RESULTS=$(awk '/Full results can be found in.*/ {print $(NF-1)}' $LOGFILE)
SUCCESSFUL=$(grep -q "Results sent to AMQ topic" $LOGFILE; echo $?)
rm -f $LOGFILE

if [ $PUBLISH == false ] || [ $SUCCESSFUL -ne 0 ];
then
  GREEN='\033[0;32m'
  NC='\033[0m' # No Color
  echo -e "${GREEN}\nThe results were not sent to AMQ. In order to send them, you can run:"
  echo -e "${WORKDIR}/${MYENV}/bin/python3 ${WORKDIR}/${MYENV}/lib/python3.6/site-packages/hepbenchmarksuite/plugins/send_queue.py --port=$PORT --server=$SERVER --topic $TOPIC --key $CERTIFKEY --cert $CERTIFCRT --file $RESULTS ${NC}"
fi

echo -e "\nYou are in python environment $MYENV. run \`deactivate\` to exit from it"
